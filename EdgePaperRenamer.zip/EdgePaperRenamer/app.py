"""Windows desktop UI; PDF files never leave the computer (only DOI is queried)."""
from __future__ import annotations
import json
import os
from pathlib import Path
import queue
import subprocess
import sys
import threading
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from core import Store, Watcher

DATA = Path(os.environ.get("LOCALAPPDATA", str(Path.home()))) / "EdgePaperRenamer"
DATA.mkdir(parents=True, exist_ok=True)

def downloads():
    if os.name == "nt":
        try:
            import winreg
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Software\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders") as key:
                return os.path.expandvars(winreg.QueryValueEx(key, "{374DE290-123F-4565-9164-39C4925E467B}")[0])
        except OSError:
            pass
    return str(Path.home() / "Downloads")

def singleton():
    f = open(DATA / "running.lock", "a+b")
    f.seek(0)
    f.write(b"0")
    f.flush()
    f.seek(0)
    try:
        if os.name == "nt":
            import msvcrt
            msvcrt.locking(f.fileno(), msvcrt.LK_NBLCK, 1)
        else:
            import fcntl
            fcntl.flock(f, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except OSError:
        f.close()
        raise RuntimeError("程序已经运行，请检查任务栏中的窗口。")
    return f

class App:
    def __init__(self, root):
        self.root = root
        root.title("PDF 文献自动命名 · Edge Paper Renamer")
        root.geometry("1040x640")
        root.minsize(820, 500)
        self.events, self.commands = queue.Queue(), queue.Queue()
        self.closed = threading.Event()
        self.review = {}
        try:
            config = json.loads((DATA / "config.json").read_text(encoding="utf-8"))
        except (OSError, ValueError):
            config = {}
        self.folder = tk.StringVar(value=config.get("folder", downloads()))
        self.status = tk.StringVar(value="选择 Edge 实际下载目录，然后点击“开始监控”。")
        frame = ttk.Frame(root, padding=14)
        frame.pack(fill="both", expand=True)
        ttk.Label(frame, text="命名格式：年份_第一作者_论文标题.pdf", font=("Microsoft YaHei UI", 14, "bold")).pack(anchor="w")
        top = ttk.Frame(frame)
        top.pack(fill="x", pady=12)
        ttk.Entry(top, textvariable=self.folder).pack(side="left", fill="x", expand=True)
        ttk.Button(top, text="选择目录", command=self.browse).pack(side="left", padx=6)
        ttk.Button(top, text="开始监控", command=self.start).pack(side="left")
        ttk.Button(top, text="暂停", command=lambda: self.commands.put(("pause", None))).pack(side="left", padx=6)
        ttk.Label(frame, text="默认只处理新下载文件；首次启动前已有的 PDF 可用下方按钮加入。子文件夹不扫描。").pack(anchor="w")
        actions = ttk.Frame(frame)
        actions.pack(fill="x", pady=10)
        for label, command in [("处理目录内已有 PDF", self.scan_existing), ("开启登录后自动启动", lambda: self.startup(True)), ("关闭自动启动", lambda: self.startup(False)), ("打开记录目录", self.open_data)]:
            ttk.Button(actions, text=label, command=command).pack(side="left", padx=(0, 8))
        tabs = ttk.Notebook(frame)
        tabs.pack(fill="both", expand=True)
        pending = ttk.Frame(tabs, padding=8)
        history = ttk.Frame(tabs, padding=8)
        tabs.add(pending, text="待确认 / 重试")
        tabs.add(history, text="改名历史")
        self.pending = self.tree(pending, ("file", "reason"), ("文件", "原因"))
        self.pending.bind("<<TreeviewSelect>>", self.select)
        fields = ttk.Frame(pending)
        fields.pack(fill="x", pady=8)
        self.fields = {k: tk.StringVar() for k in ("year", "author", "title")}
        for key, label, width in [("year", "年份", 6), ("author", "第一作者", 16), ("title", "标题", 50)]:
            ttk.Label(fields, text=label).pack(side="left", padx=4)
            ttk.Entry(fields, textvariable=self.fields[key], width=width).pack(side="left", fill="x", expand=(key == "title"))
        buttons = ttk.Frame(pending)
        buttons.pack(fill="x")
        ttk.Button(buttons, text="按填写信息改名", command=self.manual).pack(side="left")
        ttk.Button(buttons, text="重新识别", command=lambda: self.pending_action("retry")).pack(side="left", padx=8)
        ttk.Button(buttons, text="忽略该文件", command=lambda: self.pending_action("ignore")).pack(side="left")
        self.history = self.tree(history, ("time", "old", "new", "state"), ("时间", "原文件名", "新文件名", "状态"))
        ttk.Button(history, text="撤销选中的改名", command=self.undo).pack(anchor="w", pady=8)
        ttk.Label(frame, textvariable=self.status, wraplength=960).pack(fill="x", pady=(10, 0))
        ttk.Label(frame, text="只向 Crossref 发送 DOI；不上传 PDF。关闭窗口会退出，最小化可继续监控。").pack(anchor="w", pady=(6, 0))
        threading.Thread(target=self.worker, name="pdf-worker", daemon=True).start()
        self.commands.put(("refresh", None))
        root.after(250, self.pump)
        root.protocol("WM_DELETE_WINDOW", self.close)
        if "--start" in sys.argv:
            self.start()
            root.after(300, root.iconify)

    def tree(self, parent, cols, labels):
        wrap = ttk.Frame(parent)
        wrap.pack(fill="both", expand=True)
        tree = ttk.Treeview(wrap, columns=cols, show="headings", selectmode="browse")
        for col, label in zip(cols, labels):
            tree.heading(col, text=label)
            tree.column(col, width=200, minwidth=80)
        scroll = ttk.Scrollbar(wrap, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=scroll.set)
        tree.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")
        return tree

    def browse(self):
        value = filedialog.askdirectory()
        if value:
            self.folder.set(value)

    def start(self):
        folder = Path(self.folder.get()).expanduser().resolve()
        if not folder.is_dir():
            messagebox.showerror("目录不存在", "请选择 Edge 设置中显示的实际下载位置。")
            return
        (DATA / "config.json").write_text(json.dumps({"folder": str(folder)}, ensure_ascii=False), encoding="utf-8")
        self.commands.put(("start", folder))

    def scan_existing(self):
        if messagebox.askyesno("处理已有 PDF", "将把当前目录内未完成处理的 PDF 加入识别队列，识别成功后自动改名。是否继续？"):
            self.start()
            self.commands.put(("existing", None))

    def select(self, event=None):
        ids = self.pending.selection()
        if ids and ids[0] in self.review:
            info = json.loads(self.review[ids[0]]["info"])
            for key, var in self.fields.items():
                var.set(info.get(key, ""))

    def manual(self):
        ids = self.pending.selection()
        if ids:
            self.commands.put(("manual", (ids[0], {k: v.get() for k, v in self.fields.items()})))

    def pending_action(self, action):
        ids = self.pending.selection()
        if ids:
            self.commands.put((action, ids[0]))

    def undo(self):
        ids = self.history.selection()
        if ids:
            self.commands.put(("undo", int(ids[0])))

    def open_data(self):
        if os.name == "nt":
            os.startfile(DATA)
        else:
            messagebox.showinfo("记录目录", str(DATA))

    def startup(self, enable):
        if os.name != "nt":
            messagebox.showinfo("提示", "自动启动功能仅支持 Windows。")
            return
        try:
            import winreg
            with winreg.CreateKey(winreg.HKEY_CURRENT_USER, r"Software\Microsoft\Windows\CurrentVersion\Run") as key:
                if enable:
                    if getattr(sys, "frozen", False):
                        args = [sys.executable, "--start"]
                    else:
                        exe = Path(sys.executable).with_name("pythonw.exe")
                        args = [str(exe), str(Path(__file__).resolve()), "--start"]
                    winreg.SetValueEx(key, "EdgePaperRenamer", 0, winreg.REG_SZ, subprocess.list2cmdline(args))
                else:
                    try:
                        winreg.DeleteValue(key, "EdgePaperRenamer")
                    except FileNotFoundError:
                        pass
            messagebox.showinfo("设置完成", "已开启登录后自动启动。请不要移动程序文件夹。" if enable else "已关闭自动启动。")
        except OSError as exc:
            messagebox.showerror("设置失败", str(exc))

    def worker(self):
        store = Store(DATA / "records.sqlite3")
        watch = None
        active = False
        def emit(kind, value):
            if kind == "refresh":
                refresh()
            else:
                self.events.put((kind, value))
        def refresh():
            rows = [dict(r) for r in store.db.execute("SELECT * FROM files WHERE status IN ('review','retry')")]
            hist = [dict(r) for r in store.db.execute("SELECT * FROM history ORDER BY id DESC LIMIT 500")]
            self.events.put(("rows", (rows, hist)))
        while not self.closed.is_set():
            try:
                cmd, arg = self.commands.get(timeout=2)
            except queue.Empty:
                cmd, arg = "tick", None
            try:
                if cmd == "start":
                    store.baseline(arg)
                    watch, active = Watcher(store, arg, emit, self.closed.is_set), True
                    emit("message", f"监控中：{arg}")
                elif cmd == "pause":
                    active = False
                    emit("message", "已暂停监控")
                elif cmd == "existing" and watch:
                    for p in watch.folder.iterdir():
                        if p.is_file() and p.suffix.lower() == ".pdf":
                            row = store.db.execute("SELECT status FROM files WHERE path=?", (str(p),)).fetchone()
                            if not row or row[0] != "done":
                                store.record(p, "retry")
                    emit("message", "已有 PDF 已加入队列")
                elif cmd == "manual":
                    emit("message", f"已改名：{store.rename(Path(arg[0]), arg[1]).name}")
                elif cmd in ("retry", "ignore"):
                    store.record(Path(arg), "retry" if cmd == "retry" else "ignored")
                    emit("message", "已加入重试队列（需要开启该目录监控）" if cmd == "retry" else "已忽略")
                elif cmd == "undo":
                    emit("message", f"已恢复：{store.undo(arg).name}")
                if cmd != "tick":
                    refresh()
                if active and watch:
                    watch.scan()
            except Exception as exc:
                emit("error", str(exc))
        store.db.close()

    def pump(self):
        try:
            while True:
                kind, value = self.events.get_nowait()
                if kind == "message":
                    self.status.set(value)
                elif kind == "error":
                    self.status.set("错误：" + value)
                    messagebox.showerror("操作未完成", value)
                elif kind == "rows":
                    rows, hist = value
                    selected = self.pending.selection()
                    self.review = {r["path"]: r for r in rows}
                    self.pending.delete(*self.pending.get_children())
                    for row in rows:
                        self.pending.insert("", "end", iid=row["path"], values=(Path(row["path"]).name, row["note"]))
                    if selected and selected[0] in self.review:
                        self.pending.selection_set(selected[0])
                    self.history.delete(*self.history.get_children())
                    for row in hist:
                        self.history.insert("", "end", iid=str(row["id"]), values=(row["stamp"], Path(row["old"]).name, Path(row["new"]).name, "已撤销" if row["undone"] else "已改名"))
        except queue.Empty:
            pass
        self.root.after(250, self.pump)

    def close(self):
        # Let the worker finish the current file so its rename journal is committed.
        self.closed.set()
        self.status.set("正在退出，等待当前文件处理完成……")
        self.commands.put(("refresh", None))
        self.finish_close()

    def finish_close(self):
        if any(t.name == "pdf-worker" and t.is_alive() for t in threading.enumerate()):
            self.root.after(250, self.finish_close)
        else:
            self.root.destroy()

def main():
    root = tk.Tk()
    try:
        lock = singleton()
    except RuntimeError as exc:
        root.withdraw()
        messagebox.showinfo("程序已运行", str(exc))
        root.destroy()
        return
    App(root)
    root.mainloop()
    lock.close()

if __name__ == "__main__":
    main()
