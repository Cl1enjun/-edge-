@echo off
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo Run install.bat first.
  pause
  exit /b 1
)
".venv\Scripts\python.exe" -m pip install "pyinstaller>=6.22,<7"
if errorlevel 1 goto failed
".venv\Scripts\python.exe" -m PyInstaller --noconfirm --clean --onefile --windowed --name EdgePaperRenamer --collect-all pypdf app.py
if errorlevel 1 goto failed
echo Build complete: dist\EdgePaperRenamer.exe
pause
exit /b 0
:failed
echo Build failed. Read the error above.
pause
exit /b 1
