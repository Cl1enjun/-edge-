"""PDF identification and lossless filename operations. Python 3.10+."""
from __future__ import annotations
import hashlib
import html
import json
import os
import re
import sqlite3
import time
import unicodedata
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
from pypdf import PdfReader

DOI = re.compile(r"10\.\d{4,9}/[^\s<>\"]+", re.I)

def clean(value):
    value = html.unescape(re.sub(r"<[^>]*>", "", str(value or "")))
    value = unicodedata.normalize("NFC", value)
    value = re.sub(r'[<>:"/\\|?*\x00-\x1f]', " ", value)
    return re.sub(r"\s+", " ", value).strip(" ._")

def units(s):
    return len(s.encode("utf-16-le")) // 2

def trim(s, budget):
    while s and units(s) > budget:
        s = s[:-1]
    return s.rstrip(" ._")

def filename(folder, info, suffix=""):
    year, author, title = (clean(info.get(k)) for k in ("year", "author", "title"))
    if not re.fullmatch(r"(?:19|20)\d{2}", year) or not author or not title:
        raise ValueError("年份、第一作者和标题必须填写完整；年份须为四位数字。")
    prefix = year + "_" + trim(author, 35) + "_"
    # Keep below traditional Windows MAX_PATH, including the directory.
    budget = min(180, 240 - units(str(folder.resolve())) - 1)
    title_budget = budget - units(prefix + suffix + ".pdf")
    if title_budget < 12:
        raise ValueError("下载目录路径太长，请选择较短的路径。")
    return prefix + trim(title, title_budget) + suffix + ".pdf"

def digest(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()

def signature(path):
    s = path.stat()
    return f"{s.st_size}:{s.st_mtime_ns}"

def doi_list(text):
    found = []
    for m in DOI.finditer(text):
        d = m.group().rstrip(".,;:]")
        while d.endswith(")") and d.count(")") > d.count("("):
            d = d[:-1]
        if d.lower() not in [x.lower() for x in found]:
            found.append(d)
    return found

def norm(text):
    return re.sub(r"[^\w]", "", unicodedata.normalize("NFKC", text).lower())

def title_matches(title, text):
    # Exact normalized match tolerates PDF spaces, line breaks and hyphenation.
    t = norm(title)
    return len(t) >= 15 and t in norm(text)

def crossref(doi):
    url = "https://api.crossref.org/works/" + urllib.parse.quote(doi, safe="")
    req = urllib.request.Request(url, headers={"User-Agent": "EdgePaperRenamer/1.0", "Accept": "application/json"})
    with urllib.request.urlopen(req, timeout=12) as response:
        work = json.load(response)["message"]
    title = (work.get("title") or [""])[0]
    authors = work.get("author") or [{}]
    author = authors[0].get("family") or authors[0].get("name") or ""
    year = ""
    # Prefer the issue/print year; online and print dates can differ.
    for key in ("published-print", "published", "published-online", "issued"):
        date = work.get(key, {}).get("date-parts", [[]])
        if date and date[0]:
            year = str(date[0][0])
            break
    return dict(title=clean(title), author=clean(author), year=year, doi=doi, source="Crossref")

def inspect_pdf(path):
    if path.stat().st_size > 100 * 1024 * 1024:
        raise ValueError("文件超过 100 MB，请手动处理。")
    with open(path, "rb") as stream:
        reader = PdfReader(stream, strict=False)
        if reader.is_encrypted and not reader.decrypt(""):
            raise ValueError("PDF 已加密，需要手动处理。")
        if not reader.pages:
            raise ValueError("PDF 没有页面。")
        page = reader.pages[0]
        text = page.extract_text() or ""
        md = reader.metadata or {}
        title = clean(md.get("/Title", ""))
        author = clean(md.get("/Author", ""))
        author = re.split(r";|,|\band\b", author, maxsplit=1)[0].strip()
        # Only first page and metadata; do not mine the reference list.
        front = re.split(r"(?im)^\s*(?:references|bibliography|参考文献)\s*$", text)[0]
        links = []
        for ref in page.get("/Annots", []):
            try:
                action = ref.get_object().get("/A", {})
                links.append(str(action.get("/URI", "")))
            except Exception:
                pass
        candidates = doi_list(str(md) + "\n" + front + "\n" + "\n".join(links))[:5]
    years = set(re.findall(r"\b(?:19|20)\d{2}\b", front[:6000]))
    year = next(iter(years)) if len(years) == 1 else ""
    if not title or title.lower().endswith((".doc", ".docx", ".pdf")) or len(title) < 12:
        lines = [clean(x) for x in front.splitlines()[:25]]
        title = next((x for x in lines if len(x) > 25 and not re.search(r"doi|www\.|https?:|elsevier|springer|journal", x, re.I)), "")
    proposal = dict(title=title, author=author, year=year, source="PDF 候选（需确认）")
    network_failed = False
    for doi in candidates:
        try:
            result = crossref(doi)
            if result["title"] and result["author"] and result["year"] and title_matches(result["title"], front):
                return "ready", result, "DOI 与首页题名核对通过"
        except urllib.error.HTTPError as e:
            network_failed |= e.code == 429 or e.code >= 500
        except (urllib.error.URLError, TimeoutError, OSError):
            network_failed = True
        except (ValueError, KeyError, TypeError):
            pass
    if network_failed:
        return "retry", proposal, "网络或 Crossref 暂不可用，稍后自动重试"
    return "review", proposal, "未获得可核对的完整信息；请确认候选字段" if text else "未提取到文字，可能是扫描版；请手动填写（未启用 OCR）"

def move_no_overwrite(src, dst):
    if os.name == "nt":
        os.rename(src, dst)  # Windows rename fails if the destination exists.
    else:
        # No clobber even when a competing process creates dst concurrently.
        os.link(src, dst)
        os.unlink(src)

class Store:
    def __init__(self, path):
        self.db = sqlite3.connect(path)
        self.db.row_factory = sqlite3.Row
        self.db.executescript('''
        CREATE TABLE IF NOT EXISTS files(path TEXT PRIMARY KEY, sig TEXT, status TEXT,
            info TEXT, note TEXT, attempts INTEGER DEFAULT 0, retry_at REAL DEFAULT 0);
        CREATE TABLE IF NOT EXISTS folders(path TEXT PRIMARY KEY);
        CREATE TABLE IF NOT EXISTS history(id INTEGER PRIMARY KEY, old TEXT, new TEXT,
            hash TEXT, stamp TEXT, undone INTEGER DEFAULT 0);
        ''')

    def record(self, path, status, info=None, note="", attempts=0, retry_at=0):
        self.db.execute("INSERT OR REPLACE INTO files VALUES(?,?,?,?,?,?,?)",
            (str(path), signature(path), status, json.dumps(info or {}, ensure_ascii=False), note, attempts, retry_at))
        self.db.commit()

    def baseline(self, folder):
        if not self.db.execute("SELECT 1 FROM folders WHERE path=?", (str(folder),)).fetchone():
            for p in folder.iterdir():
                if p.is_file() and p.suffix.lower() == ".pdf":
                    self.record(p, "ignored", note="首次启动前已有文件")
            self.db.execute("INSERT INTO folders VALUES(?)", (str(folder),))
            self.db.commit()

    def rename(self, path, info):
        before = signature(path)
        sha = digest(path)
        for i in range(10000):
            dst = path.with_name(filename(path.parent, info, f" ({i})" if i else ""))
            if str(dst).casefold() == str(path).casefold():
                self.record(path, "done", info, "名称已符合格式")
                return path
            if signature(path) != before:
                raise OSError("文件仍在变化，暂不重命名。")
            try:
                move_no_overwrite(path, dst)
                break
            except FileExistsError:
                continue
        else:
            raise OSError("同名文件过多。")
        self.db.execute("INSERT INTO history(old,new,hash,stamp) VALUES(?,?,?,?)",
            (str(path), str(dst), sha, time.strftime("%Y-%m-%d %H:%M:%S")))
        self.db.execute("DELETE FROM files WHERE path=?", (str(path),))
        self.record(dst, "done", info, "重命名成功")
        return dst

    def undo(self, ident):
        row = self.db.execute("SELECT * FROM history WHERE id=? AND undone=0", (ident,)).fetchone()
        if not row:
            raise ValueError("记录已撤销或不存在。")
        src, dst = Path(row["new"]), Path(row["old"])
        if dst.exists():
            raise ValueError("原文件名已被占用，不能覆盖。")
        if not src.exists() or digest(src) != row["hash"]:
            raise ValueError("文件已移动或内容已变化，不能自动撤销。")
        move_no_overwrite(src, dst)
        self.db.execute("UPDATE history SET undone=1 WHERE id=?", (ident,))
        self.db.execute("DELETE FROM files WHERE path=?", (str(src),))
        self.record(dst, "ignored", note="用户已撤销，不再次自动改名")
        return dst

class Watcher:
    def __init__(self, store, folder, emit, stopped=lambda: False):
        self.store, self.folder, self.emit = store, folder, emit
        self.stable = {}
        self.stopped = stopped

    def scan(self):
        now = time.monotonic()
        for path in self.folder.iterdir():
            if self.stopped():
                break
            if not path.is_file() or path.suffix.lower() != ".pdf":
                continue
            try:
                sig = signature(path)
                previous = self.stable.get(str(path))
                if not previous or previous[0] != sig:
                    self.stable[str(path)] = (sig, now)
                    continue
                if now - previous[1] < 6 or Path(str(path) + ".crdownload").exists():
                    continue
                row = self.store.db.execute("SELECT * FROM files WHERE path=?", (str(path),)).fetchone()
                if row and row["sig"] == sig:
                    if row["status"] != "retry" or row["retry_at"] > time.time():
                        continue
                attempts = row["attempts"] + 1 if row and row["sig"] == sig else 1
                self.emit("message", f"正在识别：{path.name}")
                try:
                    status, info, note = inspect_pdf(path)
                    if signature(path) != sig:
                        self.stable.pop(str(path), None)
                        continue
                    if status == "ready":
                        dest = self.store.rename(path, info)
                        self.emit("message", f"已改名：{dest.name}")
                    else:
                        if status == "retry" and attempts >= 5:
                            status, note = "review", "多次联网失败，可点击重新识别或手动填写"
                        self.store.record(path, status, info, note, attempts, time.time() + min(60 * attempts, 300))
                except Exception as exc:
                    status = "retry" if attempts < 5 else "review"
                    self.store.record(path, status, note=str(exc), attempts=attempts, retry_at=time.time() + 60)
                self.emit("refresh", None)
            except OSError:
                continue
