@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 goto usepython
py -3 -m venv .venv
goto checkenv
:usepython
python -m venv .venv
:checkenv
if not exist ".venv\Scripts\python.exe" goto failed
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 goto failed
echo Installation complete. Double-click start.bat.
pause
exit /b 0
:failed
echo Installation failed. Install Python 3.10 or newer from python.org.
echo Enable the Python launcher and pip, then try again. Internet is required.
pause
exit /b 1
