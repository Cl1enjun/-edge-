import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import urllib.error
from pypdf import PdfWriter
from pypdf.generic import DictionaryObject, NameObject, DecodedStreamObject
import core

INFO = {"year": "2025", "author": "Wang", "title": "A novel stereo-DIC calibration method"}

def pdf(path, text="A novel stereo-DIC calibration method 10.1234/example"):
    writer = PdfWriter()
    page = writer.add_blank_page(612, 792)
    font = DictionaryObject({NameObject("/Type"): NameObject("/Font"), NameObject("/Subtype"): NameObject("/Type1"), NameObject("/BaseFont"): NameObject("/Helvetica")})
    page[NameObject("/Resources")] = DictionaryObject({NameObject("/Font"): DictionaryObject({NameObject("/F1"): writer._add_object(font)})})
    stream = DecodedStreamObject()
    stream.set_data(f"BT /F1 10 Tf 30 740 Td ({text}) Tj ET".encode("ascii"))
    page[NameObject("/Contents")] = writer._add_object(stream)
    with path.open("wb") as f:
        writer.write(f)

class Tests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.folder = self.root / "downloads"
        self.folder.mkdir()
        self.store = core.Store(self.root / "records.db")
    def tearDown(self):
        self.store.db.close()
        self.tmp.cleanup()
    def test_invalid_chars_and_unicode_length(self):
        info = dict(INFO, title='A:B/C\\D?*<>|"' + "测😀" * 100)
        name = core.filename(self.folder, info)
        self.assertNotRegex(name, r'[<>:"/\\|?*]')
        self.assertLessEqual(core.units(name), 180)
        self.assertTrue(name.endswith(".pdf"))
    def test_bad_fields(self):
        with self.assertRaises(ValueError):
            core.filename(self.folder, dict(INFO, year=""))
    def test_duplicate_does_not_overwrite_and_undo(self):
        src = self.folder / "download.pdf"
        src.write_bytes(b"original PDF bytes")
        existing = self.folder / core.filename(self.folder, INFO)
        existing.write_bytes(b"other")
        dst = self.store.rename(src, INFO)
        self.assertTrue(dst.name.endswith(" (1).pdf"))
        self.assertEqual(existing.read_bytes(), b"other")
        self.assertEqual(dst.read_bytes(), b"original PDF bytes")
        self.store.undo(1)
        self.assertEqual(src.read_bytes(), b"original PDF bytes")
        self.assertFalse(dst.exists())
    def test_undo_rejects_changed_content(self):
        src = self.folder / "a.pdf"
        src.write_bytes(b"before")
        dst = self.store.rename(src, INFO)
        dst.write_bytes(b"after")
        with self.assertRaises(ValueError):
            self.store.undo(1)
    def test_undo_rejects_occupied_name(self):
        src = self.folder / "a.pdf"
        src.write_bytes(b"before")
        self.store.rename(src, INFO)
        src.write_bytes(b"new download")
        with self.assertRaises(ValueError):
            self.store.undo(1)
        self.assertEqual(src.read_bytes(), b"new download")
    def test_baseline_once(self):
        old = self.folder / "old.pdf"
        old.write_bytes(b"old")
        self.store.baseline(self.folder)
        new = self.folder / "new.pdf"
        new.write_bytes(b"new")
        self.store.baseline(self.folder)
        rows = self.store.db.execute("SELECT * FROM files").fetchall()
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]["path"], str(old))
    def test_doi_punctuation(self):
        self.assertEqual(core.doi_list("doi:10.1234/abc. (10.1234/abc)"), ["10.1234/abc"])
    def test_verified_pdf_auto(self):
        path = self.folder / "paper.pdf"
        pdf(path)
        with patch("core.crossref", return_value=INFO):
            state, info, _ = core.inspect_pdf(path)
        self.assertEqual(state, "ready")
        self.assertEqual(info, INFO)
    def test_wrong_doi_title_goes_to_review(self):
        path = self.folder / "paper.pdf"
        pdf(path)
        with patch("core.crossref", return_value=dict(INFO, title="An unrelated cited paper on optics")):
            self.assertEqual(core.inspect_pdf(path)[0], "review")
    def test_network_failure_retry(self):
        path = self.folder / "paper.pdf"
        pdf(path)
        with patch("core.crossref", side_effect=urllib.error.URLError("offline")):
            self.assertEqual(core.inspect_pdf(path)[0], "retry")
    def test_scanned_pdf_review(self):
        path = self.folder / "scanned.pdf"
        writer = PdfWriter()
        writer.add_blank_page(612, 792)
        with path.open("wb") as f:
            writer.write(f)
        self.assertEqual(core.inspect_pdf(path)[0], "review")
    def test_waits_for_stable_download_and_only_once(self):
        path = self.folder / "paper.pdf"
        path.write_bytes(b"data")
        watcher = core.Watcher(self.store, self.folder, lambda *a: None)
        with patch("core.time.monotonic", return_value=0), patch("core.inspect_pdf") as inspect:
            watcher.scan()
            inspect.assert_not_called()
        partial = Path(str(path) + ".crdownload")
        partial.write_bytes(b"downloading")
        with patch("core.time.monotonic", return_value=10), patch("core.inspect_pdf") as inspect:
            watcher.scan()
            inspect.assert_not_called()
        partial.unlink()
        with patch("core.time.monotonic", return_value=20), patch("core.inspect_pdf", return_value=("ready", INFO, "")) as inspect:
            watcher.scan()
            self.assertEqual(inspect.call_count, 1)
            watcher.scan()
        with patch("core.time.monotonic", return_value=40), patch("core.inspect_pdf") as inspect:
            watcher.scan()
            inspect.assert_not_called()
        self.assertFalse(path.exists())
        self.assertTrue((self.folder / core.filename(self.folder, INFO)).exists())
    def test_network_retry_limit(self):
        path = self.folder / "paper.pdf"
        path.write_bytes(b"data")
        self.store.record(path, "retry", attempts=4)
        watcher = core.Watcher(self.store, self.folder, lambda *a: None)
        with patch("core.time.monotonic", return_value=0):
            watcher.scan()
        with patch("core.time.monotonic", return_value=10), patch("core.inspect_pdf", return_value=("retry", {}, "offline")):
            watcher.scan()
        row = self.store.db.execute("SELECT * FROM files").fetchone()
        self.assertEqual(row["status"], "review")
        self.assertEqual(row["attempts"], 5)
    def test_crossref_fields_and_print_year(self):
        import io
        raw = {"message": {"title": [INFO["title"]], "author": [{"family": "Wang"}], "published-print": {"date-parts": [[2025]]}, "published-online": {"date-parts": [[2024]]}}}
        with patch("core.urllib.request.urlopen", return_value=io.BytesIO(json.dumps(raw).encode())) as request:
            result = core.crossref("10.1234/a/b")
        self.assertEqual(result["year"], "2025")
        self.assertEqual(result["author"], "Wang")
        self.assertIn("10.1234%2Fa%2Fb", request.call_args.args[0].full_url)

if __name__ == "__main__":
    unittest.main()
